Custom Hook useFetch React App

About

This is a React application that uses a custom hook named useFetch to fetch data from an API and display user information.

Technologies Used

React
JavaScript
JSX
CSS
React Hooks
Fetch API

Features

Created a reusable custom hook named useFetch
Accepts API URL as a parameter
Fetches data using JavaScript Fetch API
Manages data, loading and error states
Displays user details from API
Shows loading message while fetching data
Handles API errors
Uses useEffect and useState hooks
Responsive user card layout

How to Run

Create a React project
Create useFetch.js for the custom hook
Add the given code in App.jsx
Add styling in App.css
Open the terminal in the project folder
Run npm install
Run npm run dev
Open the local URL in your browser

Author

Yash